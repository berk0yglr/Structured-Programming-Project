import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class TransactionManagementPage extends JFrame {

    private JTable transactionTable;
    private DefaultTableModel model;
    private Connection conn;

    String url = "jdbc:mysql://localhost:3306/CustomerManagementDB?useSSL=false&serverTimezone=UTC";
    String username = "root";
    String password = "131105Ber_";
    public TransactionManagementPage() {
        connectToDatabase();

        setTitle("Transaction Management");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        // Başlık
        JLabel header = new JLabel("Transaction Management", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setOpaque(true);
        header.setBackground(Color.ORANGE);
        add(header, BorderLayout.NORTH);

        // Tablo Modeli
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"Customer Name", "Goods & Service", "Amount", "Payment Status", "Transaction Date", "Phone Number", "Update"});
        transactionTable = new JTable(model) {
            public boolean isCellEditable(int row, int column) {
                return false; // Hücre düzenlenemez olsun
            }
        };
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        add(scrollPane, BorderLayout.CENTER);

        // Alt Panel (New Transaction Butonu)
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton addTransactionBtn = new JButton("New Transaction");
        bottomPanel.add(addTransactionBtn);
        add(bottomPanel, BorderLayout.SOUTH);

        // Sağ üst köşe (Filter Alanı)
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JTextField filterField = new JTextField(20);
        JButton filterBtn = new JButton("Filter");
        filterPanel.add(filterField);
        filterPanel.add(filterBtn);
        add(filterPanel, BorderLayout.PAGE_START);

        // Buton Eventleri
        addTransactionBtn.addActionListener(e -> addTransaction());
        filterBtn.addActionListener(e -> filterTransaction(filterField.getText()));

        refreshTransactionList();
        setVisible(true);
    }

    private void connectToDatabase() {
        try {
            conn = DriverManager.getConnection(url,"root","131105Ber_");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
        }
    }

    private void refreshTransactionList() {
        model.setRowCount(0);
        try {
            String sql = "SELECT t.id, c.name AS customer_name, t.goods_service, t.amount, t.payment_status, t.transaction_date, t.phone_number " +
                    "FROM Transactions t " +
                    "JOIN Customer c ON t.customer_id = c.id";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("customer_name"),
                        rs.getString("goods_service"),
                        rs.getDouble("amount"),
                        rs.getString("payment_status"),
                        rs.getDate("transaction_date"),
                        rs.getString("phone_number"),
                        "Update"
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load transactions: " + e.getMessage());
        }
    }

    private void addTransaction() {
        try {
            String customerId = JOptionPane.showInputDialog(this, "Enter Customer ID:");
            String goodsService = JOptionPane.showInputDialog(this, "Enter Goods & Service:");
            String amountStr = JOptionPane.showInputDialog(this, "Enter Amount:");
            String paymentStatus = JOptionPane.showInputDialog(this, "Enter Payment Status (Paid/Unpaid):");
            String phoneNumber = JOptionPane.showInputDialog(this, "Enter Phone Number:");
            java.sql.Date today = new java.sql.Date(System.currentTimeMillis());

            if (customerId != null && goodsService != null && amountStr != null && paymentStatus != null && phoneNumber != null) {
                String sql = "INSERT INTO Transactions (customer_id, goods_service, amount, payment_status, transaction_date, phone_number) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, Integer.parseInt(customerId));
                pstmt.setString(2, goodsService);
                pstmt.setDouble(3, Double.parseDouble(amountStr));
                pstmt.setString(4, paymentStatus);
                pstmt.setDate(5, today);
                pstmt.setString(6, phoneNumber);

                pstmt.executeUpdate();
                refreshTransactionList();
                JOptionPane.showMessageDialog(this, "Transaction added successfully!");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Insert failed: " + e.getMessage());
        }
    }

    private void filterTransaction(String keyword) {
        model.setRowCount(0);
        try {
            String sql = "SELECT t.id, c.name AS customer_name, t.goods_service, t.amount, t.payment_status, t.transaction_date, t.phone_number " +
                    "FROM Transactions t " +
                    "JOIN Customer c ON t.customer_id = c.id " +
                    "WHERE c.name LIKE ?";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + keyword + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("customer_name"),
                        rs.getString("goods_service"),
                        rs.getDouble("amount"),
                        rs.getString("payment_status"),
                        rs.getDate("transaction_date"),
                        rs.getString("phone_number"),
                        "Update"
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Filter failed: " + e.getMessage());
        }
    }
}
