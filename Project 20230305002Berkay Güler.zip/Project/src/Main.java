import javax.swing.*;
import java.awt.*;


public class Main extends JFrame {


    public Main() {
        setTitle("Welcome to System");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel titleLabel = new JLabel("Welcome to System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));

        JButton customerButton = new JButton("Customer Management");
        JButton transactionButton = new JButton("Transaction Management");

        customerButton.setFont(new Font("Arial", Font.PLAIN, 16));
        transactionButton.setFont(new Font("Arial", Font.PLAIN, 16));

        String url = "jdbc:mysql://localhost:3306/CustomerManagementDB?useSSL=false&serverTimezone=UTC";
        String username = "root";
        String password = "131105Ber_";
        customerButton.addActionListener(e -> {

            JOptionPane.showMessageDialog(this, "Customer Management ekranına geçilecek.");

            new CustomerManagementPage();
        });

        transactionButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Transaction Management ekranına geçilecek.");
            new TransactionManagementPage();
        });


        setLayout(new BorderLayout());
        JPanel centerPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        centerPanel.add(customerButton);
        centerPanel.add(transactionButton);

        add(titleLabel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Main();
    }

}
