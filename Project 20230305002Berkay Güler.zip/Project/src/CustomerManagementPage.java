import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class CustomerManagementPage extends JFrame {

    private JTextArea customerListArea;
    private Connection conn;

    String url = "jdbc:mysql://localhost:3306/CustomerManagementDB?useSSL=false&serverTimezone=UTC";
    String username = "root";
    String password = "131105Ber_";
    public CustomerManagementPage() {
        connectToDatabase();

        setTitle("Customer Management");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.DARK_GRAY);
        setLocationRelativeTo(null);

        JLabel header = new JLabel("CUSTOMER MANAGEMENT", SwingConstants.CENTER);
        header.setBounds(0, 0, 800, 50);
        header.setOpaque(true);
        header.setBackground(Color.ORANGE);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        add(header);

        JButton addBtn = new JButton("Add Customer");
        addBtn.setBounds(50, 80, 150, 60);
        add(addBtn);

        JButton deleteBtn = new JButton("Delete Customer");
        deleteBtn.setBounds(50, 300, 150, 60);
        add(deleteBtn);

        JButton updateBtn = new JButton("Update Customer");
        updateBtn.setBounds(600, 80, 150, 60);
        add(updateBtn);

        JButton recentBtn = new JButton("Recently Added Customers");
        recentBtn.setBounds(600, 300, 170, 60);
        add(recentBtn);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBounds(250, 80, 300, 280);
        centerPanel.setBackground(Color.WHITE);

        JTextField searchField = new JTextField("Search Customer");
        centerPanel.add(searchField, BorderLayout.NORTH);

        customerListArea = new JTextArea();
        customerListArea.setEditable(false);
        centerPanel.add(new JScrollPane(customerListArea), BorderLayout.CENTER);

        add(centerPanel);

        // Buton işlevleri
        addBtn.addActionListener(e -> addCustomerDialog());
        deleteBtn.addActionListener(e -> deleteCustomerDialog());
        updateBtn.addActionListener(e -> updateCustomerDialog());
        recentBtn.addActionListener(e -> showRecentCustomer());

        refreshCustomerList();
        setVisible(true);
    }

    private void connectToDatabase() {
        try {
            conn = DriverManager.getConnection(url,"root","131105Ber_");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
        }
    }

    private void addCustomerDialog() {
        String name = JOptionPane.showInputDialog(this, "Enter name:");
        String email = JOptionPane.showInputDialog(this, "Enter email:");
        String phone = JOptionPane.showInputDialog(this, "Enter phone:");
        String address = JOptionPane.showInputDialog(this, "Enter address:");

        if (name != null && email != null && phone != null && address != null) {
            try {
                String sql = "INSERT INTO Customer (name, email, phone, address) VALUES (?, ?, ?, ?)";

                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, name);
                stmt.setString(2, email);
                stmt.setString(3, phone);
                stmt.setString(4, address);
                stmt.executeUpdate();
                refreshCustomerList();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Insert failed: " + e.getMessage());
            }
        }
    }

    private void deleteCustomerDialog() {
        ArrayList<String> names = getAllCustomerNames();
        if (names.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No customers to delete.");
            return;
        }

        String selectedName = (String) JOptionPane.showInputDialog(this, "Select customer to delete:",
                "Delete Customer", JOptionPane.PLAIN_MESSAGE, null, names.toArray(), names.get(0));

        if (selectedName != null) {
            try {
                String sql = "DELETE FROM Customer WHERE name = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, selectedName);
                stmt.executeUpdate();
                refreshCustomerList();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Delete failed: " + e.getMessage());
            }
        }
    }

    private void updateCustomerDialog() {
        ArrayList<String> names = getAllCustomerNames();
        if (names.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No customers to update.");
            return;
        }

        String selectedName = (String) JOptionPane.showInputDialog(this, "Select customer to update:",
                "Update Customer", JOptionPane.PLAIN_MESSAGE, null, names.toArray(), names.get(0));

        if (selectedName != null) {
            try {
                String sql = "SELECT * FROM Customer WHERE name = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, selectedName);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String newName = JOptionPane.showInputDialog(this, "Enter new name:", rs.getString("name"));
                    String newEmail = JOptionPane.showInputDialog(this, "Enter new email:", rs.getString("email"));
                    String newPhone = JOptionPane.showInputDialog(this, "Enter new phone:", rs.getString("phone"));
                    String newAddress = JOptionPane.showInputDialog(this, "Enter new address:", rs.getString("address"));

                    String updateSql = "UPDATE Customer SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?";
                    PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                    updateStmt.setString(1, newName);
                    updateStmt.setString(2, newEmail);
                    updateStmt.setString(3, newPhone);
                    updateStmt.setString(4, newAddress);
                    updateStmt.setInt(5, rs.getInt("id"));
                    updateStmt.executeUpdate();

                    refreshCustomerList();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Update failed: " + e.getMessage());
            }
        }
    }

    private void showRecentCustomer() {
        try {
            String sql = "SELECT TOP 1 * FROM Customer ORDER BY id DESC";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                String message = "Most Recently Added Customer:\n\n" +
                        "Name: " + rs.getString("name") + "\n" +
                        "Email: " + rs.getString("email") + "\n" +
                        "Phone: " + rs.getString("phone") + "\n" +
                        "Address: " + rs.getString("address");
                JOptionPane.showMessageDialog(this, message, "Recently Added", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No customers found.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void refreshCustomerList() {
        customerListArea.setText("");
        try {
            String sql = "SELECT * FROM Customer";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                customerListArea.append(
                        "Name: " + rs.getString("name") +
                                "\nEmail: " + rs.getString("email") +
                                "\nPhone: " + rs.getString("phone") +
                                "\nAddress: " + rs.getString("address") + "\n\n"
                );
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load customer list: " + e.getMessage());
        }
    }

    private ArrayList<String> getAllCustomerNames() {
        ArrayList<String> names = new ArrayList<>();
        try {
            String sql = "SELECT name FROM Customer";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                names.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load names: " + e.getMessage());
        }
        return names;
    }
}
