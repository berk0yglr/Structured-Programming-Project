import java.sql.*;

public class DatabaseConnection {
    public static void main(String[] args) {
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");


            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/CustomerManagementDB", "root", "131105Ber_");


            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM customer");


            while (rs.next()) {
                System.out.println("Müşteri Adı: " + rs.getString("name") +
                        " | E-posta: " + rs.getString("email"));
            }


            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
